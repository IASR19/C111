import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

nike = pd.read_csv("nike.csv", delimiter=";")

#Q1
val1 = nike[['name','sub_title']].where(nike['price']==nike['price'].max())
print(val1)

#Q2
print(len(nike['set'][nike['set'].str.contains('yes')])).mean()

#Q3
preta = len(nike['color'].where(nike['color'].str.contains('black')))
print((1-preta)*100)

#Q4
estoque = nike['name'].str.contains('Air Jordan')[nike['availability'].str.contains('OutOfStock')]
print(estoque)






